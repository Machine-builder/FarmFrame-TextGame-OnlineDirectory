import json, time, random, threading, sys, os

import requests

from colorama import *

RED, WHITE, BLUE, GREEN, YELLOW, PINK = Fore.RED, Fore.WHITE, Fore.BLUE, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA

LIGHTGREEN = Fore.LIGHTGREEN_EX
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
LIGHTBLUE = Fore.LIGHTBLUE_EX

try:
    url = 'https://www.google.com/'
    r = requests.get(url)
    status = "Connected"

except:
    status = "Not connected"

import pyAdventure.modules.pyAdventure_lootHandle as pal
import pyAdventure.modules.pyAdventure_craftingHandle as pac
import pyAdventure.modules.pyAdventure_textHandle as pat

import farmframe_modules.intro as intro
import farmframe_modules.classes as cla
import farmframe_modules.texts as texts

import farmframe_modules.crafters as crafters

TEXTSPACING = 20

r = os.system('title xxx FarmFrame xxx')

def dumpSave(): open('save.json', 'w').write(json.dumps(save))



# LOADS ALL SAVE DATA WITH VARIABLES FROM LAST RUN
save = json.loads(open('save.json').read()) # Load save
save_begin = json.loads(open('save_begin.json').read()) # Load empty save

newsave = save_begin.copy()
newsave.update(save)

save = newsave.copy()
dumpSave()



playerVars = save["playerVariables"]
INVENTORY, TYPE, HP, FOOD, THIRST = playerVars['playerInventory'], "player", playerVars['playerHealth'], playerVars['playerFoodbar'], playerVars['playerThirstbar']
username = playerVars['username']

TIRE = playerVars['playerTired']
MAXTIRE = playerVars['playerMaxTired']

PD = cla.CharacterTracker('player', HP, FOOD, THIRST, username, TIRE)


varDat = save['variableData']


resourceData = save['resourceVariables']
WoodChopCount = resourceData['wood_output_resources']
MiningCount = resourceData['mining_output_resources']
ExtractCount = resourceData['mineral_output_resources']

WoodChopDelay = resourceData['chop_delay']
MineDelay = resourceData['mine_delay']
ExtractDelay = resourceData['mineral_extraction_delay']

warehouseChests = save['warehouseChests']

resourceOutputs = json.loads(open('resources.json').read())

RESOURCE_TREE = resourceOutputs['resource_tree']
RESOURCE_TREE_TABLE = pal.WeightedTable(RESOURCE_TREE)

RESOURCE_MINE = resourceOutputs['resource_mine']
RESOURCE_MINE_TABLE = pal.WeightedTable(RESOURCE_MINE)

RESOURCE_EXTRACTION = resourceOutputs['resource_rock']
RESOURCE_EXTRACTION_TABLE = pal.WeightedTable(RESOURCE_EXTRACTION)

th = pat.TextHandle()

RECIPES = json.loads(open('recipes.json').read())


# Crafting_no_table = crafting object
REC_crafter_no_table = RECIPES['crafting_no_table']
# print(REC_crafter_no_table)
CRAFTER_NO_TABLE = pac.Crafting( REC_crafter_no_table , pal)


# Crafting_crafter = crafting object
REC_crafter_crafter = REC_crafter_no_table.copy()
REC_crafter_crafter.update( RECIPES['crafting_crafter'] )
# print(REC_crafter_crafter)
CRAFTER_CRAFTER = pac.Crafting( REC_crafter_crafter , pal)


# Crafting_material_reducer = crafting object
REC_crafter_material_reducer = RECIPES['crafting_crafter']
# print(REC_crafter_material_reducer)
CRAFTER_MATERIAL_REDUCER = pac.Crafting( REC_crafter_material_reducer , pal)


ARRANGER = pal.arranger()


def get_tired(c):
    global PD
    PD.tire += c

    if PD.tire > MAXTIRE:
        PD.hp -= c
        PD.tire = MAXTIRE

    if PD.hp < 0:
        PD.hp = 0
        print(texts.dead)
        th.prompt('...')
        sys.exit(-1)



th.clearScreen()

HOURDELAY = 20

DAYTIME = varDat['dayTime']
SLEEPDELAY = varDat['sleepDelay']

AUTOSAVE_DELAY = 10

def increaseDay():
    global DAYTIME
    DAYTIME += 1
    if DAYTIME > 24: DAYTIME = 0

def timeLoop():
    global DAYTIME
    while 1:
        start = time.time()
        while not time.time() > start+HOURDELAY: pass # Wait HOURDELAY seconds
        increaseDay()

def saveLoop():
    while 1:
        start=time.time()
        while not time.time() > start+AUTOSAVE_DELAY: pass
        dumpSave()


threading._start_new_thread(timeLoop, tuple())
threading._start_new_thread(saveLoop, tuple())


def INVSTRING():
    invstring = f'{YELLOW}'; invlist = ARRANGER.sort_inventory(INVENTORY)
    for tupe in invlist:
        invstring += f'* %s {WHITE}:{YELLOW} %s\n' % (tupe[0].ljust(TEXTSPACING), tupe[1])
    invstring = invstring[:-1]
    invstring+=WHITE
    return invstring

# INTRO TO GAME

if save['first_time'] == 1:
    intro.executeIntro()
    save['first_time'] = 0

    print("\nWelcome to FarmFrame!..")
    x = th.prompt('What is your name?\n>>> ')
    save['playerVariables']['username'] = x

    dumpSave()

else:
    print(f"Welcome back to FarmFrame, {username}!")
    th.prompt('...')


SLEEP_HOUR_INCREASE_REPLAY_COUNT = 10

# MAIN LOOP

BARSIZES = 60.0

def daystate():
    day = 'NIGHT'

    if DAYTIME > 6 and DAYTIME < 18:
        day = 'DAY'

    if DAYTIME > 5 and DAYTIME < 9:
        day = 'MORNING'

    if DAYTIME > 15 and DAYTIME < 19:
        day = 'AFTERNOON'

    dayText = f'{DAYTIME} ; {day}'
    return dayText

def getTiredBar():
    tire_percent = int(PD.tire / MAXTIRE * 100)

    bar_tired = str( tire_percent ) + '% : ' + ('=' * int( tire_percent*(BARSIZES/100.0) ) ) + ('-' * int(BARSIZES - int( tire_percent*(BARSIZES/100.0) ) ))
    return bar_tired



# SEND VARIABLES TO OTHER MODULE
crafters.getVariables(th, ARRANGER)



while 1:
    th.clearScreen()

    print(texts.main_menu % (daystate()))
    x = th.prompt('>>> ')
    try:
        x=int(x)
    except:
        continue

    if x == 10:
        th.clearScreen()
        intro.executeIntro()

    if x == 5: # Mineral extracter
    
        while 1:
            th.clearScreen()

            invstring = INVSTRING()

            print(texts.menu_extracter_mineral % (invstring))
            c = th.prompt('>>> ')

            try: c=int(c)
            except: continue

            if c == 1:
                break

            elif c == 0:
                print("Extract minerals from rocks (uses coal from inventory)")

                while 1:
                    count=input("Enter amount of rocks to extract minerals from\n>>> ")
                    try:
                        count = int(count)
                        break
                    except: print("Input must be an integer")
                
                print("Extracting minerals, please wait... (press Ctrl+C to cancel)")

                allOut = {}

                try:

                    for i in range(count):
                        
                        percent = int((float(i+1)/float(count)) * 100.0)
                        print(f"Extracing; {percent}%...", '           ', end='\r')

                        if not ARRANGER.inventory_contained_in_inventory(INVENTORY, {"coal": 1}):
                            print()
                            print("Out of coal!")
                            break

                        INVENTORY = ARRANGER.subtract_inventory_from_container(INVENTORY, {"coal": 1})
                        # Use 1 coal per extraction
                        INVENTORY = ARRANGER.subtract_inventory_from_container(INVENTORY, {"rock": 1})

                        resources = RESOURCE_EXTRACTION_TABLE.loadRandom(ExtractCount, ExtractCount+2)
                        resources = ARRANGER.convert_list_to_inventory(resources)

                        allOut = ARRANGER.add_container_to_inventory(allOut, resources)

                        time.sleep(ExtractDelay)
                
                except:
                    print()
                    print("Extraction cancelled.")

                print()
                print("Extraction completed.")

                INVENTORY = ARRANGER.add_container_to_inventory(allOut, INVENTORY)
                INVENTORY = ARRANGER.remove_zero_values(INVENTORY)

                print("Output resources :")
                for i in allOut:
                    print(f'{YELLOW}*', i.ljust(TEXTSPACING), f'{WHITE}:{YELLOW}', allOut[i], WHITE)

                th.prompt('...')


    
    if x == 0: # stat viewer
        th.clearScreen()

        divisionNumber = (100.0 / BARSIZES)
        tiredNumber = int(MAXTIRE / BARSIZES)

        bar_tired = getTiredBar()

        bar_hp = str( int((PD.hp) )) + '% : ' + ( '='*int( PD.hp / divisionNumber ) ) + ( '-'*int( BARSIZES-(PD.hp / divisionNumber) ) )
        bar_food = str( int((PD.food) )) + '% : ' + ( '='*int( PD.food / divisionNumber ) ) + ( '-'*int( BARSIZES-(PD.food / divisionNumber) ) )
        bar_water = str( int((PD.thirst) )) + '% : ' + ( '='*int( PD.thirst / divisionNumber ) ) + ( '-'*int( BARSIZES-(PD.thirst / divisionNumber) ) )

        print(texts.menu_stat_viewer % (bar_tired, bar_hp, bar_food, bar_water))
        th.prompt('...')

    if (x == 1) or (x==2):
        print("No hunger, health or thirst is in this game yet!")
        th.prompt('...')

    if x == 9:
        print("Please wait, saving progress...")
        save['warehouseChests'] = warehouseChests

        v = {
            'username': PD.name,
            'playerInventory': INVENTORY,
            'playerHealth': PD.hp,
            'playerFoodbar': PD.food,
            'playerThirstbar': PD.thirst,

            'playerTired': PD.tire,
            'playerMaxTired': MAXTIRE
        }

        varDat['dayTime'] = DAYTIME
        varDat['sleepDelay'] = SLEEPDELAY

        save['variableData'] = varDat

        save['playerVariables'] = v

        dumpSave()
        print("Saved!")
        th.prompt('...')

    if x == 4:
        while 1: # mine active
            th.clearScreen()
            print(texts.menu_mine)
            x = th.prompt('>>> ')
            try: x=int(x)
            except: continue

            if x == 1: # leave mine
                break
            
            elif x == 0:
                print("Mining...")

                PD.tire += 2
                if 'NIGHT' in daystate(): PD.tire += 1

                time.sleep(MineDelay)

                print("Mined resources")
                resout = RESOURCE_MINE_TABLE.loadRandom(MiningCount, MiningCount+2)
                resout = ARRANGER.convert_list_to_inventory(resout)
                INVENTORY = ARRANGER.add_container_to_inventory(resout, INVENTORY)

                print("Output resources :")
                for i in resout:
                    print(f'{YELLOW}*', i.ljust(TEXTSPACING), f'{WHITE}:{YELLOW}', resout[i], WHITE)

                print("Resources have been added to your inventory.")

                print("Inventory :")

                invstring = INVSTRING()

                print(invstring)

                th.prompt('...')

    if x == 3:
        while 1: # forrest active
            th.clearScreen()
            print(texts.menu_forrest)
            x = th.prompt('>>> ')
            try: x=int(x)
            except: continue

            if x == 1: # leave forrest
                break
            
            elif x == 0:
                print("Chopping wood...")

                PD.tire += 1
                if 'NIGHT' in daystate(): PD.tire += 1

                time.sleep(WoodChopDelay)
                
                print("Chopped wood")
                resout = RESOURCE_TREE_TABLE.loadRandom(WoodChopCount, WoodChopCount+2)
                resout = ARRANGER.convert_list_to_inventory(resout)
                INVENTORY = ARRANGER.add_container_to_inventory(resout, INVENTORY)

                print("Output resources :")
                for i in resout:
                    print(f'{YELLOW}*', i.ljust(TEXTSPACING), f'{WHITE}:{YELLOW}', resout[i], WHITE)

                print("Resources have been added to your inventory.")

                print("Inventory :")

                invstring = INVSTRING()

                print(invstring)

                th.prompt('...')
    
    if x == 7:
        while 1:
            th.clearScreen()
            print(texts.menu_home % (daystate()))
            x = th.prompt('>>> ')
            try: x=int(x)
            except: continue

            if x == 2: # Back to main menu
                break

            elif x == 0: # Sleep to lower tiredness
                print("Sleeping...")
                print("Press Ctrl+C to wake")
                try:
                    COUNT=0
                    while PD.tire > 0:
                        PD.tire -= 1
                        if 'NIGHT' in daystate(): PD.tire -= 1 # Sleep faster at night
                        time.sleep(SLEEPDELAY)
                        bar_tired = getTiredBar()
                        print('Tiredness :', '['+bar_tired+']', ' '*int(BARSIZES), '                    ', end = '\r')
                        COUNT+=1
                        if COUNT > (SLEEP_HOUR_INCREASE_REPLAY_COUNT-1):
                            COUNT = 0
                            increaseDay()


                except: pass
                print()
                print("You have woken up from sleep")
                th.prompt('...')

            elif x == 1:
                while 1:
                    INVENTORY = ARRANGER.remove_zero_values(INVENTORY)

                    th.clearScreen()

                    invstring = INVSTRING()

                    print(texts.menu_inventory % (invstring))
                    x = th.prompt(">>> ")
                    try: x=int(x)
                    except: continue

                    if x == 1: # Leave menu
                        break
                    
                    if x == 0: # Use item
                        print("Use an item")

                        while 1:
                            itemName = th.prompt("Enter item name\n(type 'craft' to craft without a workbench/crafter!)\n>>> ").lower()

                            if itemName == 'craft': break

                            if itemName in INVENTORY: break

                            if not itemName: break

                            print(f'{itemName} is not in your inventory!')

                        if itemName:
                            if itemName == 'craft':
                                invout = crafters.loopCrafter(CRAFTER_NO_TABLE, INVENTORY, 0.3)
                                INVENTORY = invout

                            if itemName == 'crafter':
                                invout = crafters.loopCrafter(CRAFTER_CRAFTER, INVENTORY, 0.2)
                                INVENTORY = invout

                            if itemName == 'material reducer':
                                invout = crafters.loopCrafter(CRAFTER_MATERIAL_REDUCER, INVENTORY, 0.2)
                                INVENTORY = invout
