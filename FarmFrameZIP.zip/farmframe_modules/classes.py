"""impletementation of classes for FarmFrame"""

class CharacterTracker():
    """Tracks values such as name, type,
    hp, food, thirst, & tiredness"""

    def __init__(self, type='npc', hp=100,food=100,thirst=100, name = 'xxx', tire=0):
        self.type = type
        self.hp = hp
        self.food = food
        self.thirst = thirst
        self.tire = tire

        self.name = name