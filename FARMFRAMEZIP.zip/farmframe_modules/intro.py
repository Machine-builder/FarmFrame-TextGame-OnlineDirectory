import pyAdventure.modules.pyAdventure_textHandle as pat

intro = """
Welcome to FarmFrame!

This is a text based
resource gathering game!

The main ideas of this game :
chop trees, & craft things!

First, you'll need to gather
wood, stone & other minerals...

once you've found coal,
you can craft a furnace
to refine metals to create
automation machinery!...



In FarmFrame, 
each time you perform an action,
such as, chop a tree, you become
gradually more tired.

When you are fully tired,
you begin to loose health
each time you perform an action.

to counteract tiredness,
you can go home & sleep.
sleeping is 2x more effective
during the FarmFrame night
time. Daytime is between
hours 6 - 18.

Chopping wood & mining at
night makes you more tired!
Do that during the daytime!

"""
crafting_help = """
Crafting in FarmFrame!

in FarmFrame,
you can craft many
items. It may seem
slightly daunting at
first, you know,
the whol text-based layout
and all.

But don't worry!
You'll get used to it &
it'll become second nature ;)

When you first begin,
you don't have access to
any form of advanced crafter.

**note :
to use a crafter, go
to :
- menu :
 - go home :
  - manage inventory:
   - use item
...

list of all different
types of
crafters/fabricaters/refiners :

 * craft :
        the simplest method of crafting.
        crafts below 10 different items

        (0.3 second item craft delay)

 * crafter :
        the first 'advanced' crafter.
        crafts 10+ items

        (0.2 second item craft delay)

 * material reducer :
        2nd type of 'advanced' crafting
        unit. Used to reduce materials
        to lower elements, i.e :
        sand > quarts > silicon + oxygen
        elements like silicon are used
        in microchips & processors

        (0.2 second item reduce delay)

"""

def executeIntro():
    print(intro)
    input("Press enter to continue\n...\n")