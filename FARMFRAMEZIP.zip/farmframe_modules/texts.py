from colorama import *

RED, WHITE, BLUE, GREEN, YELLOW, PINK = Fore.RED, Fore.WHITE, Fore.BLUE, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA

LIGHTGREEN = Fore.LIGHTGREEN_EX
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
LIGHTBLUE = Fore.LIGHTBLUE_EX





main_menu = f"""\
{BLUE}xxx FarmFrame Menus xxx{WHITE}

FarmFrame Time : %s

Goto choices :

[0] : stat viewer - KEEP WATCH OF HUNGER & THIRST ... WIP

[1] : waterfall - COLLECT WATER
[2] : berry bush - COLLECT FOOD ... WIP

[3] : forrest - COLLECT WOOD
[4] : mine - COLLECT ROCKS & STONE

[5] : mineral exracter - EXTACT MINERALS FROM ROCKS AND STONE
[6] : trader - TRADE ITEMS/MINERALS FOR REWARDS

[7] : go home - MANAGE INVENTORY, USE ITEMS, SLEEP, CRAFT NEW ITEMS
[8] : warehouse - ACCESS STORAGE CHESTS & CREATE CHESTS

[9] : save progress - SAVE YOUR PROGRESS
[10] : read game information - HOW TO PLAY

[11] : automation - GET RESOURCES DELIVERED TO YOU

.........."""

menu_stat_viewer = f"""\
{BLUE}xxx Stat Viewer xxx{WHITE}

*Tiredness :   [%s] # implemented

*Health :      [%s] # unimplemented
*Food :        [%s] # unimplemented
*Water :       [%s] # unimplemented

.........."""

menu_forrest = f"""\
{BLUE}xxx FarmFrame forrest xxx{WHITE}

Action choices :

[0] : collect wood - GATHER WOOD, ACORNS & VINES
[1] : leave - EXIT FORREST

.........."""

menu_mine = f"""\
{BLUE}xxx FarmFrame mine xxx{WHITE}

Action choices :

[0] : mine - GATHER ROCKS & SAND
[1] : leave - EXIT MINE

.........."""


menu_waterfall = f"""\
{BLUE}xxx FarmFrame waterfall xxx{WHITE}

Action choices :

[0] : fill canister - COLLECT WATER
(requires empty canister)

[1] : leave - EXIT MINE

.........."""
dead = f"""\
{RED}You've died!...{WHITE}

don't worry!...

you can still load
your previous save!
Just close & reopen
FarmFrame"""

menu_home = f"""\
{BLUE}xxx FarmFrame home menu xxx{WHITE}

FarmFrame Time : %s

Action choices :

[0] : go to sleep - REST & LOOSE TIREDNESS
[1] : manage inventory - USE ITEMS & CRAFT

[2] : leave home - BACK TO MAIN MENU

.........."""

menu_inventory = f"""\
{BLUE}xxx FarmFrame inventory xxx{WHITE}

Inventory contents :

%s

Action choices :

[...] : use item - USE AN ITEM (ie. crafting bench / furnace)
(type the name of the item that you want to use)
(or type one of the numbers below...)

[1] : close menu - BACK TO HOME MENU

[2] : search items - LOOKUP ITEMS IN INVENTORY

.........."""

menu_extracter_mineral = f"""\
{BLUE}xxx FarmFrame mineral extracter xxx{WHITE}

Inventory contents :

%s

Action choices :

[0] : extract minerals - EXTRACT MINERALS FROM ROCKS

[1] : leave - BACK TO MAIN MENU

.........."""
