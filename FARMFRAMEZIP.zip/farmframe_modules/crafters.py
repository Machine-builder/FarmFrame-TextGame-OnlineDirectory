"""impletementation of crafters for FarmFrame"""

import os, time
from colorama import *

RED, WHITE, BLUE, GREEN, YELLOW, PINK = Fore.RED, Fore.WHITE, Fore.BLUE, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA

LIGHTGREEN = Fore.LIGHTGREEN_EX
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
LIGHTBLUE = Fore.LIGHTBLUE_EX

def getVariables(TH, ar):
    global th, ARRANGER, sort_inventory
    th = TH
    ARRANGER = ar

    sort_inventory = ARRANGER.sort_inventory


def INVSTRING(inv):
    longestName = 0
    for i in inv:
        if len(i)>longestName:
            longestName = len(i)
    
    longestName += 2
    TEXTSPACING = longestName

    invstring = f'{YELLOW}'; invlist = ARRANGER.sort_inventory(inv)
    for tupe in invlist:
        invstring += f'* %s {WHITE}:{YELLOW} %s\n' % (tupe[0].ljust(TEXTSPACING), tupe[1])
    invstring = invstring[:-1]
    invstring+=WHITE
    return invstring

def cls():
    r=os.system('cls')

craftmenu = f"""\
{BLUE}xxx FarmFrame crafting xxx{WHITE}

Using Crafter : %s
Crafting Time : %s

Action choices :

[0] : view all recipes - THERE CAN BE A LOAD!
(HARD TO FIND WHAT YOU'RE LOOKING FOR)

[1] : view all possible recipes -
GET A LIST OF ALL RECIPES THAT YOU CAN MAKE

[2] : search recipes (by name) - EASIER TO FIND WHAT YOU NEED
[3] : search recipes (by requirements) - EASIER TO FIND WHAT YOU NEED

[4] : craft a recipe - CRAFT SOMETHING FROM MATERIALS

[5] : exit - CLOSE THIS MENU

[6] : check inventory - VIEW INVENTORY CONTENTS

........."""

TEXTSPACING = 20

def displayrec(recSort, rec):
    print(f"{BLUE}xxx FarmFrame crafting recipes xxx{WHITE}")
    for item in recSort:
        out = rec[item]['output_items']
        # print(rec[item])
        recName = item

        print(f'\nTo craft {YELLOW}{out}{WHITE} {GREEN}({recName}){WHITE}, you need the following;')
        for i2 in rec[item]['ingredients']:
            print(f'{YELLOW}*', str(i2).ljust(TEXTSPACING), f'{WHITE}:{YELLOW}', str(rec[item]['ingredients'][i2]), f'{WHITE}')
    
    th.prompt('...')
    print()

def loopCrafter(crafting_object, inv, craftDelay, crafterName = '__unnamedcrafter__crafter__'):
    global INV
    INV = inv

    cls()
    while 1:

        print(craftmenu % (crafterName, craftDelay))
        x = th.prompt('>>> ')
        try: x=int(x)
        except: continue

        if x == 5:
            return INV

        if x == 0: # VIEW ALL RECIPES
            cls()

            rec = crafting_object.recipes
            recSort = sorted(rec)
            displayrec(recSort, rec)

        if x == 1: # VIEW ALL POSSIBLE RECIPES
            cls()

            rec = sorted(crafting_object.recipes)

            newList = []
            for item in rec:
                # print(item)
                if crafting_object.canCraft(INV, item):
                    newList.append(item)
            
            recSort = newList

            if len(recSort) < 1:
                print("You cannot craft any of these recipes")

            rec=crafting_object.recipes
            displayrec(recSort, rec)

        if x == 2: # SEARCH BY NAME
            cls()

            search = th.prompt("Enter search phrase\n(searches recipe name, not ingredients or outputs)\n>>> ")

            rec = crafting_object.recipes
            recSort = sorted(rec)

            newList = []
            for item in recSort:
                if str(search) in str(item):
                    newList.append(item)
            
            recSort = newList

            if len(recSort) < 1:
                print("No recipes were found with that search phrase")

            displayrec(recSort, rec)

        if x == 3: # SEARCH BY REQUIREMENTS
            cls()

            search = th.prompt("Enter search phrase\n(searches recipe requirements (ingredients))\n>>> ")

            rec = crafting_object.recipes

            newList = []

            for item in rec:

                itemDict = rec[item]

                sorted_ingredients = itemDict['ingredients']
                sorted_ingredients = sorted(sorted_ingredients)

                for itemX in sorted_ingredients:
                    if str(search) in str(itemX):
                        if not item in newList:
                            newList.append(item)
            
            recSort = newList

            if len(recSort) < 1:
                print("No recipes were found with that search phrase")

            displayrec(recSort, rec)

        if x == 4:
            recsea = th.prompt("Enter recipe name\n>>> ").lower()

            rec = crafting_object.recipes
            if not recsea in sorted(rec):
                print("No recipes were found with that name.\nMake sure puctuation is correct!")
                th.prompt('...')
                continue

            while 1:
                amount = th.prompt("Enter amount to craft (integer)\n(will crafting to that amount or\nwhen the recipe is no longer affordable)\n>>> ")
                if not amount: amount = 1
                try: amount=int(amount); break
                except: continue

            print("Crafting. Press Ctrl + C to stop")

            recipe = recsea
            # print(recipe)
            cls()

            try:

                for i in range(amount):
                    percent = int((float(i) / float(amount)) * 100)

                    print(f'Crafting... {percent} %...', '                  ', end='\r')

                    ret = crafting_object.craft(INV, recipe)
                    if ret == 'cannot_craft':
                        print()
                        print("Out of items!")
                        break

                    INV = ret
                    # print(INV)
                    
                    time.sleep(craftDelay)

                if i == (amount-1):
                    print()
                    print("Crafting complete.")

            except:
                print()
                print("Crafting stopped.")

            th.prompt('...')

        if x == 6:
            cls()

            invstring = INVSTRING(INV)

            print(f"{BLUE}xxx FarmFrame inventory xxx{WHITE}")
            print()
            print(invstring)
            print()
            th.prompt('...')

    return INV