import json, time, random, threading, sys, os

import requests
from urllib.request import urlopen

from zipfile import ZipFile

from colorama import *

RED, WHITE, BLUE, GREEN, YELLOW, PINK = Fore.RED, Fore.WHITE, Fore.BLUE, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA

LIGHTGREEN = Fore.LIGHTGREEN_EX
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
LIGHTBLUE = Fore.LIGHTBLUE_EX


try:
    url = 'https://www.google.com/'
    r = requests.get(url)
    status = "Connected"

except:
    status = "Not connected"


if status == 'Connected':
    print("Looking online for updates...")

    http = json.loads(open('httpsLocs.json','r').read())

    changelog = http['changelog']['online_location']
    online_version = http['version_file']['online_location']

    zip_file = http['zip_file']['online_location']
    zip_file_location = http['zip_file']['directory_location']

    online_ver = int(requests.get(online_version).text)
    current_ver = int(open('offline_version.txt').readline())

    if online_ver > current_ver:
        print(f"{PINK}There's a new version of the game avaiable!{WHITE}")

        changelog = requests.get(changelog).text
        print("Changelog :\n")
        print(YELLOW, changelog, WHITE)
        print("\n")

        yn = input("Do you want to download it?\n(yes / no)\n>>> ").lower()

        if 'y' in yn:

            print("Ok... Downloading update...")

            r = requests.get(zip_file, cookies={'cookie1': 'working'})
            open(zip_file_location, 'wb').write(r.content)

            print("Downloaded!")

            open('offline_version.txt', 'w').write(str(online_ver))

            install = input("Do you want to install the update?\n(yes / no)\nIf no, you must install the update manually...\nIf you want to install the update automatically\nbut said no, just change the contents of\nthe version.txt file to 0\n>>> ").lower()
            
            if 'y' in install:
                # Install
                print("Installing update...")

                # SAVE SAVE DATA FIRST!
                save = open('save.json', 'r').read()

                # THIS LINE IS NOT IMPORTANT....
                open('save.json', 'w').write(save)

                offlineVer = open('offline_version.txt', 'r').read()

                # EXTRACT ZIP
                ZIP = ZipFile(zip_file_location, 'r')
                ZIP.extractall()
                # & INSTALL

                # AFTER EXTACT, RE-INSTALL OLD SAVE FILE
                open('save.json', 'w').write(save)

                open('offline_version.txt', 'w').write(offlineVer)

                print("Installed!")

            else:
                print("FarmFrame update will not install.")

        else:
            print("FarmFrame will not update.")

    elif online_ver == current_ver:
        print(f"{PINK}You're all up to date!{WHITE}")

input("... press enter to launch FarmFrame ...")

_ = os.system('cls')
_ = os.system("0_runPython3Ansicon.bat FarmFrame.py")