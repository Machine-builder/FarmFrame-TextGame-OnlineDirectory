import os
from colorama import *

RED, WHITE, BLUE, GREEN, YELLOW, PINK = Fore.RED, Fore.WHITE, Fore.BLUE, Fore.GREEN, Fore.YELLOW, Fore.MAGENTA
CYAN = Fore.CYAN

LIGHTGREEN = Fore.LIGHTGREEN_EX
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
LIGHTBLUE = Fore.LIGHTBLUE_EX

wiki = {
    "craft": {
        "description": """\
        The original crafter in the game.

        Used when you have no crafter.
        Can only create basic materials.
        Such as :
        - bark
        - plank
        - rope
        - crafter
        - charcoal""",

        "category": "crafter"
    },
    "crafter": {
        "description": """\
        The 2nd crafter in the game.

        Used to create other crafters.
        Cannot craft any other items!
        Makes crafters such as
        - furnace
        - material reducer
        - electricians crafter
        - mechanics crafter""",

        "category": "crafter"
    },
    "furnace": {
        "description": """\
        The first smelter in the game

        Turns ores into ingots.
        Has a relatively long craft time.""",
        "category": "crafter"
    },
    "material reducer": {
        "description": """\
        An advanced crafter.

        Reduces materials to fundamentals.
        Used to extract silicon from sand.
        Used to get oxygen.

        example :
        sandstone -> sand -> quartz+gravel
        quartz -> silicon+oxygen.""",
 
        "category": "crafter"
    },
    "electricians crafter": {
        "description": """\
        An advanced crafter.

        Used to create wires
        & microchips to sell to
        merchants & craft into
        automating tasks.""",
 
        "category": "crafter"
    },
    "mechanics crafter": {
        "description": """\
        An advanced crafter.

        Used to create canisters,
        hydraulic presses & more.""",
 
        "category": "crafter"
    },
    "hydraulic press": {
        "description": """\
        An type of crafter.

        Used to convert ingot
        types into plates.
        Plates can then be
        turned into wire.
        (used in microchips)""",
 
        "category": "crafter"
    },
    "automation crafter": {
        "description": """\
        An type of crafter.

        Used to craft automation
        modules. Check the
        automation category
        for more information.""",
 
        "category": "crafter"
    },

    # MATERIALS

    "rope": {
        "description": """\
        A material.
        
        The fundamental of
        the first few crafters.
        
        Rope and wood can be
        made into planks & can
        be used to build different
        crafters.""",
 
        "category": "material"
    },
    "plank": {
        "description": """\
        A material.
        
        Made from rope & wood,
        
        Used to craft many crafters.""",
 
        "category": "material"
    },
    "bark": {
        "description": """\
        A material.
        
        Made from wood,
        
        Used to make stripped bark
        which is used to make rope
        when you run out of vines.""",
 
        "category": "material"
    },
    "stripped bark": {
        "description": """\
        A material.
        
        Made from regular bark.
        
        Used to make rope.""",
 
        "category": "material"
    },
    "glass": {
        "description": """\
        A material.
        
        Made from sand in a furnace.
        
        Is a crafting ingredient.""",
 
        "category": "material"
    },

    # ADVANCED MATERIALS

    "empty canister": {
        "description": """\
        An advanced material.
        
        Crafted from pipes.
        (iron ingots)""",
 
        "category": "advanced material"
    },
    "oxygen canister": {
        "description": """\
        An advanced material.
        
        Crafted from an
        empty canister & oxygen.
        
        (oxygen comes from quartz)
        (oxygen is made in the material reducer)
        
        Used by hydraulic press.""",
 
        "category": "advanced material"
    },
    "water canister": {
        "description": """\
        An advanced material.
        
        Collected at the waterfall
        in an empty canister.
        
        Used to make electrolyte for
        batteries.""",
 
        "category": "advanced material"
    },
    "oxygen": {
        "description": """\
        An advanced material.
        
        Extracted from quartz in
        the material reducer.
        
        Used to fill empty
        canisters.""",
 
        "category": "advanced material"
    },

    # ELECTRONICS

    "copper wire": {
        "description": """\
        An electrical part.
        
        Crafted from copper plates.
        Copper plates from copper
        ingots in the hydraulic press.
        
        Copper wires are used in
        microchips.""",
 
        "category": "electronics"
    },
    "microchip": {
        "description": """\
        An electrical part.
        
        Crafted from copper wires
        & silicon.
        
        Microchips are used in
        processors.""",
 
        "category": "electronics"
    },
    "processor": {
        "description": """\
        An electrical part.
        
        Crafted from microchips.
        
        Used in automation modules.
        Also used in computers.""",
 
        "category": "electronics"        
    },
    "sodium chloride": {
        "description": """\
        The chemical name of salt.
        When combined with water,
        produces a type of Electrolyte
        (salt water)
        
        Formed in the material reducer.

        Electrolyte is used in batteries.""",
 
        "category": "electronics"
    },
    "charged battery": {
        "description": """\
        A source of power.
        
        Crafted from zinc & electrolyte.
        
        Used by the electrical furnace""",
 
        "category": "electronics"
    },

    # AUTOMATION

    "auto wood module": {
        "description": """\
        An automation module.
        
        Used to gather wood
        automatically & straight
        to your inventory.""",
 
        "category": "automation"
    },

    # RESOURCES

    "wood": {
        "description": """\
        A resource.
        
        Gathered from the forrest.

        Can be turned into a selection
        of useful materials.""",
 
        "category": "resource"
    },
    "vine": {
        "description": """\
        A resource.
        
        Gathered from the forrest.

        Can be turned into rope.""",
 
        "category": "resource"
    },
    "acorn": {
        "description": """\
        A resource.
        
        Gathered from the forrest.

        No use as of yet.""",
 
        "category": "resource"
    },
    "rock": {
        "description": """\
        A resource.
        
        Gathered from the mine.

        Can be turned into minerals
        using the extractor available
        from the main menu.""",
 
        "category": "resource"
    },
    "sandstone": {
        "description": """\
        A resource.
        
        Gathered from the mine.

        Can be turned into sand
        in the material reducer
        or the hydraulic press.""",
 
        "category": "resource"
    },
    "dirt": {
        "description": """\
        A resource.
        
        Gathered from the mine.

        No use as of yet.""",
 
        "category": "resource"
    },
    "sand": {
        "description": """\
        A resource.
        
        Gathered from the mine.

        Can be turned into quartz
        in the material reducer.""",
 
        "category": "resource"
    },
    "coal": {
        "description": """\
        A resource.
        
        Gathered from the mine.

        Source of fuel for the
        furnace""",
 
        "category": "resource"
    },
    "salt": {
        "description": """\
        A resource.
        
        Gathered from mining.

        Useful for making electrolyte
        which is used in batteries.""",
 
        "category": "resource"
    },
    "cobblestone": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        Used to craft a furnace.""",
 
        "category": "resource"
    },
    "copper ore": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        Can be turned into ingots
        through the use of a furnace,
        then can be turned into plates
        with a hydraulic press,
        & can then be turned into
        wire with the electricians crafter.
        (copper wire is used in microchips)""",
 
        "category": "resource"
    },
    "iron ore": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        Can be turned into ingots
        through the use of a furnace,
        iron ingots are a handy for
        many crafting recipes.""",
 
        "category": "resource"
    },
    "zinc": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        A component in batteries.""",
 
        "category": "resource"
    },
    "emerald": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        Sellable to the merchants.""",
 
        "category": "resource"
    },
    "diamond": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.

        Sellable to the merchants.""",
 
        "category": "resource"
    },
    "ruby": {
        "description": """\
        A resource.
        
        Gathered from the mineral extracter.
        (the most common out of
        diamonds, emeralds & rubies)

        Sellable to the merchants.""",
 
        "category": "resource"
    }
}

categories = []
for item in wiki:
    if not wiki[item]['category'] in categories: categories.append(wiki[item]['category'])
categories.sort()

MENU = """\
xxx FarmFrame item wiki xxx

[0] : search items

[1] : search a category

........."""

while 1:
    os.system('cls')
    print(MENU)

    try: x=int(input(">>> "))
    except: continue

    if x == 0:
        os.system('cls')
        c=input("Enter search phrase\n>>> ")

        wikiInfo = {}
        for item in sorted(wiki):
            # print(wiki[item]['description'])
            if c in item:
                wikiInfo[item] = {'name': wiki[item], 'description': wiki[item]['description'], 'category': wiki[item]['category']}

        if len(wikiInfo)<1:
            print("No results were found for that search!")

        else:
            print("Search results :")
            for item in wikiInfo:
                print(PINK, item)
                print(CYAN, "  - description :")
                print(YELLOW, wikiInfo[item]['description'])
                print(CYAN, f"  - category : {GREEN}%s{WHITE}" % (wikiInfo[item]['category']))
                print(WHITE)

        input('...')

    if x == 1:
        os.system('cls')
        print("Categories :")
        for i in categories:
            print(f" * {GREEN}{i}{WHITE}")
        c=input("Enter category\n>>> ")

        if not c in categories:
            print("That's not a category. Valid categories are :")
            for i in categories:
                print(f" * {GREEN}{i}{WHITE}")

        else:

            wikiInfo = {}
            for item in sorted(wiki):
                if wiki[item]['category'] == c:
                    wikiInfo[item] = {'name': wiki[item], 'description': wiki[item]['description'], 'category': wiki[item]['category']}

            if len(wikiInfo)<1:
                print("No items were found belonging to that category")

            else:
                print("Search results :")
                for item in wikiInfo:
                    print(PINK, item)
                    print(CYAN, "  - description :")
                    print(YELLOW, wikiInfo[item]['description'])
                    print(CYAN, f"  - category : {GREEN}%s{WHITE}" % (wikiInfo[item]['category']))
                    print(WHITE)

        input('...')
