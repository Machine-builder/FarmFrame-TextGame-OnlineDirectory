import random, time

# try:
#     import modules.pyAdventure_lootHandle as pyAd
# except:
#     import pyAdventure_lootHandle as pyAd

info = """

xxx RECIPE EXAMPLE xxx

{
    'plank': {
        'ingredients' : {
            'wood':2,
            'rope':1
        },
        'output_items' : {
            'plank':1
        }
    },
    'fire': {
        'ingredients': {
            'rock':8,
            'flint':1,
            'steel':1,
            'wood':5
        },
        'output_items' : {
            'fire':1,
            'charcoal':3
        }
    }
}

where 'plank' & 'fire' are
merely refferable names,
and the actual output item
is in the output_items section

xxx NOTE xxx

if you do not want crafting
to use an item, but want the
recipe to 'require' an item,
set the item count in the
'ingredients' to 0.

"""

class handle():
    def __init__(self):
        self.type = '__handler__'

    def inventory_contained_in_inventory(self, container, INVENTORY):
        """checks whether 'INVENTORY' is
        in 'container'.
        Example :
        {
            'dirt': 2,
            'rock': 1
        } (INVENTORY)
        is contained in :
        {
            'dirt': 19,
            'rock': 30,
            'gem': 2
        } (container)"""

        con = container
        inv = INVENTORY

        IN = True
        for item in inv:
            n, c = item, inv[item]

            if not n in con: # If the item name is not in container
                return False

            if not (con[n] > inv[n]-1): # If the item count in the container is NOT higher than the item count in the INVENTORY
                return False
        
        return True

    def subtract_inventory_from_container(self, container, INVENTORY):
        """removes inventory from larger
        inventory (container)...
        Used when crafting to subtract
        the required ingredients.
        
        returns 'impossible_subtraction'
        if the values will go into
        negatives.
        
        (in crafting, INVENTORY is the recipe
        & container is the character's inv...
        
        returs the variable 'container'"""

        if not self.inventory_contained_in_inventory(container, INVENTORY):
            return('impossible_subtraction')

        I = INVENTORY
        C = container

        for item in I:
            C[item] -= I[item]
        
        return C

class Crafting():

    def __init__(self, recipes, pyAdventure_lootHandle_instance):
        """Generates a crafting handler
        the 'info' variable contains the
        required recipe format.
        
        example recipes :
        look in 'info' variable

        ....
        Note: Crafting can also be
        used as a trade-system between
        the player & an npc"""

        self.recipes = recipes
        # print(recipes)
        # input('...')

        self.handle = handle()

        self.pyAd = pyAdventure_lootHandle_instance
        self.arranger = self.pyAd.arranger()

    def canCraft(self, INVENTORY, recipe):
        """tests to see if there
        are the correct contents in
        the 'INVENTORY' to craft the item
        defined in 'recipe'.

        returns 'error_invalid_recipe'
        if there is no defined recipe
        with given name.

        otherwise, returns True if
        carfting is possible,
        otherwise False if crafting
        is not possible."""

        if not recipe in self.recipes:
            return 'error_invalid_recipe'
        
        craft = self.recipes[recipe]['ingredients']
        # print(craft)

        if not self.handle.inventory_contained_in_inventory(INVENTORY, craft):
            # print('no')
            return False 
        
        # print('yes')
        return True

    def craft(self, INVENTORY, recipe):
        """returns new inventory
        missing the items that were
        required to craft the specific
        recipe.
        Example (using example recipe) :

        ...craft({'wood':6,'rope':9}, 'plank'})

        would return inventory :
        {'wood':4,'rope':8,'plank':1}
        
        ....
        
        returns 'cannot_craft' if
        'INVENTORY' does not cotain
        required items"""

        if not self.canCraft(INVENTORY, recipe):
            return 'cannot_craft'
        
        craft = self.recipes[recipe]['ingredients']
        output = self.recipes[recipe]['output_items']

        newInv = self.handle.subtract_inventory_from_container(INVENTORY, craft)

        newInv = self.arranger.add_container_to_inventory(output, newInv)

        return self.arranger.remove_zero_values(newInv)