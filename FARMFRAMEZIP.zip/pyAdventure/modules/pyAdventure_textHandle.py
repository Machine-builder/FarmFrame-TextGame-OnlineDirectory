import random, time, os, msvcrt
class TextHandle():

    def __init__(self):
        """Generates an object
        used to display text on-screen
        in easier ways rather than
        'print()'."""

        self.type = 'text_handle'
        self.ignore = True

    def clearScreen(self):
        r=os.system('cls')

    def displayOverwritableLine(self, text):
        print(text.ljust(len(text)+20), end = '\r')

    def prompt(self, prompt):
        return input(prompt)

    def smart_prompt(self, prompt, curser_flick_delay = 0.3, curser_type = '|', banned_characters = [], ban_all = False, FILTER = None, MAX_LEN = None):
        """smart input() function
        ...
        
        FILTER can be :
        - None
        - 'numbers_only'"""

        FILTER_numbers_only = '0123456789'

        print(prompt)

        BACKSPACE = b'\x08'; ENTER = b'\r'; TAB = b'\t'

        flick_delay = curser_flick_delay

        string = ''; last = '   '

        flick = False

        start = time.time()
        while True:

            if time.time() > start+flick_delay:
                if flick: flick = False
                else: flick = True
                start = time.time()

            if msvcrt.kbhit():
                ch = msvcrt.getch()

                if ch == BACKSPACE: string = string[:-1]

                elif ch == ENTER: print(string, '      '); break

                elif ch == TAB:
                    if (FILTER == None):
                        string += '\t'

                else:
                    if (FILTER == None):
                        if not ch.decode() in banned_characters:
                            if not ban_all:
                                string += ch.decode()
                    
                    elif (FILTER == 'numbers_only'):
                        if ch.decode() in FILTER_numbers_only:
                            if not ban_all:
                                string += ch.decode()

            if not (MAX_LEN == None):
                if str(type(MAX_LEN)) == "<class 'int'>":
                    while len(string) > MAX_LEN:
                        string = string[:-1]

            stringX = string
            if flick: stringX+=curser_type

            print(stringX, '              ', end = '\r')

        return string