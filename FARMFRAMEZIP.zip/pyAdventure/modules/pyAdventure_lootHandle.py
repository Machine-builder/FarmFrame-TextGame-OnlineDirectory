import random, time

# try:
#     import modules.pyAdventure_craftingHandle as pach
# except:
#     import pyAdventure_craftingHandle as pach

class arranger:

    def __init__(self):
        self.type = 'arranger'
        self.ignore = True

    def inventory_contained_in_inventory(self, container, INVENTORY):
        """checks whether 'INVENTORY' is
        in 'container'.
        Example :
        {
            'dirt': 2,
            'rock': 1
        } (INVENTORY)
        is contained in :
        {
            'dirt': 19,
            'rock': 30,
            'gem': 2
        } (container)"""

        con = container
        inv = INVENTORY

        IN = True
        for item in inv:
            n, c = item, inv[item]

            if not n in con: # If the item name is not in container
                return False

            if not (con[n] > inv[n]-1): # If the item count in the container is NOT higher than the item count in the INVENTORY
                return False
        
        return True

    def subtract_inventory_from_container(self, container, INVENTORY):
        """removes inventory from larger
        inventory (container)...
        Used when crafting to subtract
        the required ingredients.
        
        returns 'impossible_subtraction'
        if the values will go into
        negatives.
        
        (in crafting, INVENTORY is the recipe
        & container is the character's inv...)
        
        returs the variable 'container'"""

        if not self.inventory_contained_in_inventory(container, INVENTORY):
            return('impossible_subtraction')

        I = INVENTORY
        C = container

        for item in I:
            C[item] -= I[item]
        
        return C

    def convert_list_to_inventory(self, LIST=[]):
        """converts something like :
        ['dirt', 'dirt', 'dirt', 'rock', 'stone', 'rock']
        to something like :
        {'dirt': 3, 'rock': 2, 'stone': 1}
        """

        dictOut = {}
        for item in LIST:
            if not item in dictOut:
                dictOut[item] = 1
            else:
                dictOut[item] += 1

        return dictOut
    
    def convert_inventory_to_list(self, INVENTORY):
        """converts something like :
        {'dirt': 3, 'rock': 2, 'stone': 1}
        to something like :
        ['dirt', 'dirt', 'dirt', 'rock', 'stone', 'rock']
        """

        listOut = []
        for item in INVENTORY:
            for _ in range(INVENTORY[item]):
                listOut.append(item)

        return listOut

    def sort_list(self, LIST):
        """sorts a given list"""

        return sorted(LIST)

    def sort_inventory(self, INVENTORY):
        """sorts an inventory...
        from :
        {'dirt':3, 'stone':2, 'gem':1}
        to :
        [
            ('dirt', 2),
            ('gem', 1),
            ('stone', 2)
        ]
        (alphabetical sorting)"""

        outList = []
        for item in sorted(INVENTORY):
            tmp = (item, INVENTORY[item])
            outList.append(tmp)
        return outList

    def remove_zero_values(self, INVENTORY):
        """returns new inventory
        without items that have a
        value of 0.

        Example :
        {'dirt': 1, 'stone': 2, 'gem': 0}
        Returns :
        {'dirt': 1, 'stone': 2}
        
        (zero values occur after
        crafting, but are auto-handled
        & removed in the crafting function"""

        newInv = {}

        I = INVENTORY
        for item in INVENTORY:
            if I[item] < 1:
                continue

            newInv[item] = I[item]

        return newInv

    def add_container_to_inventory(self, container, INVENTORY):
        """adds 'container' to
        'INVENTORY'. Useful for
        adding specific items
        to container.

        Example :
        inv = {'dirt':2,'rock':1}
        container = {'dirt':4, 'rock':2, 'stone':1}

        add_container_to_inventory(container, inv)

        returns :
        {'dirt':6, 'rock':3, 'stone':1}
        
        returns new INVENTORY"""

        C = container
        I = INVENTORY

        for item in C:
            if item in I:
                I[item] += C[item]
            else:
                I[item] = C[item]

        return I


class WeightedTable():

    def __init__(self, weightDictionary):
        """Generates a weighted loot table
        example :
        {
            'gold': 5,
            'gem': 2,
            'stone': 10
        }
        
        This example has a 5 in 17 chance
        to drop gold as an output item,
        a 10 in 17 chance to drop stone,
        and a 2 in 17 chance to drop gem."""

        self.dict = weightDictionary
        self.list = []
        for item in self.dict:
            for _ in range(self.dict[item]): self.list.append(item)

    def loadRandom(self, itemCountMin=1, itemCountMax=None):
        """Randomly selects item(s) from its weighted list
        which is defined when the class is instantiated
        
        returns something like :
        ['wood', 'wood', 'acorn']"""

        if itemCountMax == None:
            itemCountMax = itemCountMin
        self.randomLoad = []
        self.randomCount = random.randint(itemCountMin, itemCountMax)
        for _ in range(self.randomCount):
            self.randomLoad.append(random.choice(self.list))

        return self.randomLoad